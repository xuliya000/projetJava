package representation;


// c'est une classe abstraite car contient une methode abstraite
public abstract class Node implements Event{
	
	private String description ;
	// Variable qui compte le nombre de node existants donc qui doit etre static
	private static int nbNodeTotal=0 ;
	// Identifiant unique associe a une instance 
	// Une fois definit ne change plus
	private final int idNode ;

	public Node(String s) {
		this.description = s ;
		this.idNode = ++nbNodeTotal ;
		}

	// methode abstraite (qui n'a pas de corps) que l'on devra implementer dans toutes les classes filles
	@Override
	public abstract Node chooseNext();
	
	@Override
	public void display() {
		System.out.println( "Description:" + description );
	}
	
	//Les getters et setters
	public int getIdNode() {
		return idNode;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
