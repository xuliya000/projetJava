package univers;

public class Sorcier extends Heros{

	// constructeur
	public Sorcier(String name, int userID) {
		super(name, userID);
	}
	
	@Override 
	public void attaquerMonstre(Monster m) {
		System.out.println("Vous avez lancer un sort. ");
		if(m.getForce()>this.getLevel()*2) {
			System.out.println("Le monstre "+ m.getName()+ " est trop puissant pour vous. Votre niveau est trop faible . ");
		}
		else {
			this.gainExp(m.getXp());
			System.out.println("Le monstre "+ m.getName()+ " a été tué. Vous avez gagnez "+ m.getXp()+" xp.");
		}
	}
	
	

}
