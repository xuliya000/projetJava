package univers;

public class Fee {
	private Element ele;
	private int price;
	
	public Element getEle() {
		return ele;
	}
	public void setEle(Element ele) {
		this.ele = ele;
	}
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	// constructeur
	public Fee(Element ele, int price) {
		this.ele = ele;
		this.price = price ;
	}
	
	// methode pour afficher
	public void afficherFee() {
		System.out.println("La fée est d'élément : "+this.getEle()+", son prix est : "+this.getPrice());
	}
	
	
}
