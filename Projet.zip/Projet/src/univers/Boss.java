package univers;

import java.util.HashMap;
import java.util.Map;

public class Boss {
	private String name;
	private static int nbBoss=0 ;
	private final int bossId;
	private int difficulty;
	private Element element;
	
	
	// constructeur
	public Boss(String name, int difficulty,Element ele) {
		this.name= name;
		this.bossId =++nbBoss;
		this.difficulty = difficulty ;
		this.setElement(ele);
        // Ajouter le nom du boss à la map lors de la création
        bossNames.put(bossId, name);
        
        
	}
	
    // Map pour stocker les noms des boss en fonction de leurs identifiants
    private static Map<Integer, String> bossNames = new HashMap<>();

	//getters et setters
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public static int getNbBoss() {
		return nbBoss;
	}
	
	public static void setNbBoss(int nbBoss) {
		Boss.nbBoss = nbBoss;
	}
	
	public int getBossId() {
		return bossId;
	}
	
	public int getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(int difficulty) {
		this.difficulty = difficulty;
	}
	
	public Element getElement() {
		return element;
	}

	public void setElement(Element element) {
		this.element = element;
	}
		
    // methode pour obtenir le nom à l'aide de l'identifiant
    public String getBossName(int id) {
        return bossNames.get(id);
    }
	
    // methode pour afficher
    public void afficherBoss() {
        System.out.println("ID du boss: " + this.getBossId() + ", Nom: " + this.getName() + ", Difficulté: " + this.getDifficulty());
    }
	
	
	
	// Methode principal
	public static void main(String[] args) {
        // Création d'instances de la classe Boss
        Boss boss1 = new Boss("Dragon de feu ",3,Element.Feu);
        Boss boss2 = new Boss("Sorcier Maléfique",2,Element.Terre);

        // Affichage des informations des boss
        boss1.afficherBoss();
        boss2.afficherBoss();


        // Utilisation de la méthode pour obtenir le nom à l'aide de l'identifiant
        int bossIdToFind = 1;
        String bossName = boss1.getBossName(bossIdToFind);

        if (bossName != null) {
            System.out.println("Nom du boss avec ID " + bossIdToFind + ": " + bossName);
        } else {
            System.out.println("Aucun boss trouvé avec l'ID " + bossIdToFind);
        }
		
	}


	
}
