package univers;

public class Archer extends Heros{

	// constructeur
	public Archer(String name, int userID) {
		super(name, userID);
	}


	@Override 
	public void attaquerMonstre(Monster m){
		System.out.println(" Vous avez tirer un arc. ");
		if(m.getForce()>this.getLevel()*2) {
			System.out.println(" Le monstre"+ m.getName()+ "est trop puissant pour vous. ");
		}
		else {
			this.gainExp(m.getXp());
			System.out.println(" Le monstre"+ m.getName()+ " a été tué ");
		}
	}
	
	

}