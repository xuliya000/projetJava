package univers;

public enum Element {Feu, Eau, Terre, Air};

