package univers;

public enum Metier {Sorcier, Epeiste, Archer}
