package univers;

public class AnimalMagic extends Animal {
	private int price;
	
	// constructeur
	public AnimalMagic(String name, Heros heros) {
		super(name, heros);
		this.sauvageCapture = true;
	}
	
	// getters et setters
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	

}
