package representation;
import java.util.Scanner ;

public class DecisionNode extends InnerNode {

	// Constructeur
	public DecisionNode(String description, Node[] nextNodes) {
		super(description, nextNodes);
		// TODO Auto-generated constructor stub
	}
	
	public Node chooseNext() {
		// Demander a l'utilisateur quel node il veut choisir
		System.out.println("Choisir un node: (saisir une valeur entre 1 et 4");
		Scanner saisieUtilisateur = new Scanner(System.in);
		int choix = saisieUtilisateur.nextInt();
		saisieUtilisateur.close();
		return nextNodes[choix] ;
	}
}
