package univers;

public class Epeiste extends Heros{

	// constructeur
	public Epeiste(String name, int userID) {
		super(name, userID);
	}
	
	@Override 
	public void attaquerMonstre(Monster m){
		System.out.println(" Vous avez donné un coup. ");
		if(m.getForce()>this.getLevel()*2) {
			System.out.println(" Le monstre"+ m.getName()+ "est trop puissant pour vous. ");
		}
		else {
			this.gainExp(m.getXp());
			System.out.println(" Le monstre"+ m.getName()+ " a été tué ");
		}
	}

}
