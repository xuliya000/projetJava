package univers;

public class Lieu {
	private String name;
	private static int nbTotalLieu=0;
	private final int lieuId ;
	
	// constructeur
	public Lieu ( String name ) {
		this.name = name;
		this.lieuId = ++nbTotalLieu ;
	}
	
	public static int getNbTotalLieu() {
		return nbTotalLieu;
	}
	
	public static void setNbTotalLieu(int nbTotalLieu) {
		Lieu.nbTotalLieu = nbTotalLieu;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public int getLieuId() {
		return lieuId;
	}
	
	// methode pour afficher
	public void afficher(){
		System.out.println("Vous etes dans "+this.getName()+".");
	}
	

}
