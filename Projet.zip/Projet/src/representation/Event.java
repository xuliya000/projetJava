package representation;

public interface Event {
	public void display();
	public Node chooseNext();

}
