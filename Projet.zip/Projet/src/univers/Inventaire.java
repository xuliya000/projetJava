package univers;

import java.util.ArrayList;
import java.util.List;

public class Inventaire {
	private static int nbInventaire=0;
	private final int inventaireId ;
	private Heros heros;
    private List<Fee> fees;
    private List<Animal> animaux;
    private List<Skin> skins;

    public Inventaire(Heros heros) {
    	this.setHeros(heros);
        this.fees = new ArrayList<>();
        this.animaux = new ArrayList<>();
        this.skins = new ArrayList<>();
        this.inventaireId = ++nbInventaire;
    }

    // Méthodes pour ajouter des éléments à l'inventaire
    public void ajouterFee(Fee fee) {
        fees.add(fee);
    }

    public void ajouterAnimal(Animal animal) {
        animaux.add(animal);
    }

    public void ajouterSkin(Skin skin) {
        skins.add(skin);
    }
    
    // getters et setters
	public Heros getHeros() {
		return heros;
	}

	public void setHeros(Heros heros) {
		this.heros = heros;
	}

	public int getInventaireId() {
		return inventaireId;
	}

    
    // Méthode pour afficher l'inventaire
    public void afficherInventaire() {
        System.out.println("Fees dans l'inventaire :");
        for (Fee fee : fees) {
            fee.afficherFee();
        }

        System.out.println("\nAnimaux dans l'inventaire :");
        for (Animal animal : animaux) {
            animal.afficherAnimal();
        }

        System.out.println("\nSkins dans l'inventaire :");
        for (Skin skin : skins) {
            skin.afficherSkin();
        }
    }
    

    // methode principale 
    public static void main(String[] args) {

		Sorcier monHeros = new Sorcier("Superman", 1);
        Inventaire inventaire = new Inventaire(monHeros);


        Fee fee1 = new Fee(Element.Eau,100);
        Animal animal1 = new Animal("Lion",monHeros);
        Skin skin1 = new Skin(Metier.Archer, Element.Air, 3);

        inventaire.ajouterFee(fee1);
        inventaire.ajouterAnimal(animal1);
        inventaire.ajouterSkin(skin1);

        inventaire.afficherInventaire();
    }



}