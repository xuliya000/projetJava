package representation;

public abstract class Decorateur implements Event {
    private Event Event;

    public Decorateur(Event Event) {
        this.Event = Event;
    }

    @Override
    public void display() {
    	Event.display();
    }

    @Override
    public Node chooseNext() {
        return Event.chooseNext();
    }
}
