package univers;

public class Monster {
	// des petits monstres que le heros peut tuer pour gagner de l experience
	private String name;
	private int force ;
	private static int nbmonstre=0;
	private final int monstreId;
	// experience et piece apporter au joueur
	private int xp ;
	private int piece;
	
	
	// constructeur
	public Monster(String name, int force, int xp, int piece) {
		this.name = name ;
		this.force = force ;
		this.xp = xp ;
		this.setPiece(piece) ;
		this.monstreId = ++nbmonstre;
	}
	
	
	//getters et setters
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public int getForce() {
		return force;
	}

	public void setForce(int force) {
		this.force = force;
	}

	public static int getNbmonstre() {
		return nbmonstre;
	}

	public static void setNbmonstre(int nbmonstre) {
		Monster.nbmonstre = nbmonstre;
	}

	public int getMonstreId() {
		return monstreId;
	}

	public int getXp() {
		return xp;
	}

	public void setXp(int xp) {
		this.xp = xp;
	}
	
	
	public int getPiece() {
		return piece;
	}


	public void setPiece(int piece) {
		this.piece = piece;
	}

	
	// methode pour afficher
	public void afficherMonster() {
		System.out.println("ID du monstre : " + monstreId);
        System.out.println("Nom du monstre : " + name);
        System.out.println("Force du monstre : " + force );
        System.out.println("XP apporté : " + xp );
        System.out.println("Piece d'or apporté : " + piece );
	}
	
	
	
	
	
	// methode principal
	
	public static void main(String[] args) {
		Monster monster1 = new Monster( "poule sauvage", 1, 50, 100);
        Monster monster2 = new Monster( "belier sauvage", 2, 20, 150 );

        monster1.afficherMonster();
        monster2.afficherMonster();

        System.out.println("Nombre total de monstre : " + Monster.getNbmonstre()) ;
    }

}
