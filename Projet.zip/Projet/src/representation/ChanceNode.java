
package representation;
import java.util.Random;

public class ChanceNode extends InnerNode {

    public ChanceNode(String description, Node[] nextNodes) {
        super(description, nextNodes);
    }

    public Node chooseNext() {
        Random random = new Random();
        int nbAleatoire = random.nextInt(nextNodes.length);
        return nextNodes[nbAleatoire];
    }
}