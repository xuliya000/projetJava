package univers;

public class Utilisateur {
	private final String userName;
	private static int nbUser;
	private final int userID;
	
	// constructeur
	public Utilisateur(String name) {
		this.userName = name ;
		this.userID   = ++nbUser ;
	}

	
	// gettters et setters 
	public String getUserName() {
		return userName;
	}
	
	public static int getNbUser() {
		return nbUser;
	}
	
	public int getUserID() {
		return userID;
	}
	
	// methode pour afficher l utilisateur
	public void afficherUser() {
        System.out.println("Nom de l utilisateur : " + userName);
        System.out.println("ID de l utisateur : " + userID);
	}
	
	// methode principale (pour tester)
	public static void main(String[] args) {
        Utilisateur user1 = new Utilisateur("Liya");
        Utilisateur user2 = new Utilisateur("Junyi");

        user1.afficherUser();
        user2.afficherUser();

        System.out.println("Nombre total d'utilisateurs : " + Utilisateur.getNbUser());
    }
	
	
}
