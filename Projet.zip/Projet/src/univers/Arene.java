package univers;

public class Arene extends Lieu {
	private static int nbArene=0;
	private final int num;
	private final Boss boss;
	// si le heros arrive a battre l'arene il remporte le skin
	private Skin skin;
		
	// constructeur
	public Arene(String name, Boss boss, Skin skin) {
		super(name);
		this.num = ++ nbArene;
		this.boss = boss;
		this.setSkin(skin);
	}

	// setters et getters
	public int getNum() {
		return num;
	}

	public Boss getBoss() {
		return boss;
	}
	
	public Skin getSkin() {
		return skin;
	}

	public void setSkin(Skin skin) {
		this.skin = skin;
	}
	
	// methode pour afficher
	public void afficherArene() {
		System.out.println("Vous etes dans l'arene "+this.getNum()+", pour affronter le boss:"+this.boss.getName());
	}
	
	// methode qui renvoie un boolean, true si le heros est vainqueur, false sinon
	public boolean estVainqueur(Heros heros) {
		Element eleboss = this.getBoss().getElement();
		int bonus = 0 ;
		switch (eleboss) {
			case Feu:
				if (heros.getFee().getEle()== Element.Eau ) {
					bonus++;
					if (heros.getSkin()!= null) {
						bonus++;
					}
				}
			case Eau :
				if (heros.getFee().getEle()== Element.Terre ) {
					bonus++;
					if (heros.getSkin()!= null) {
						bonus++;
					}
				}
			case Terre:
				if (heros.getFee().getEle()== Element.Feu ) {
					bonus++;
					if (heros.getSkin()!= null) {
						bonus++;
					}
				}
			case Air:
				// il n'y a pas de bonus	
		}
		if(heros.getLevel()+ bonus < this.getBoss().getDifficulty()) {
			System.out.println("Vous avez perdu.");
			return false;
		}
		System.out.println("Vous avez gagné.");
		heros.getInventaire().ajouterSkin(this.skin);
		System.out.println("Vous avez obtenu un nouveau skin: ");
		this.getSkin().afficherSkin();
		return true;
	}
	



	
}
