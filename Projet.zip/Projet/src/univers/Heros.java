package univers;

public abstract class Heros implements Equipement, Elevage {
	private String name ;
	private int level = 1 ;
	private int exp = 0 ;
	private static int nbTotalHeros=0 ;
	private final int herosID ;
	private double piece = 5000 ;
	private final int userID ;
	private Fee fee = null;
	private Skin skin= null;
	private Animal animal = null;
	private final Inventaire inventaire;
	
	
	// le heros a un metier : sorcier, archer ou combattant
	
	// Constructeur
	public Heros(String name, int userID) {
		this.name = name;
		this.herosID = ++nbTotalHeros;
		this.userID = userID;
		this.inventaire = new Inventaire(this);
	}
	
	// Getters et Setters
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getHerosID() {
		return herosID;
	}

	public double getPiece() {
		return piece ;
	}

	public void setPiece(double piece) {
		this.piece = piece;
	}

	public int getUserID() {
		return userID;
	}
	
	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}
	
	public Fee getFee() {
		return fee;
	}

	public void setFee(Fee fee) {
		this.fee = fee;
	}
	public Skin getSkin() {
		return skin;
	}

	public void setSkin(Skin skin) {
		this.skin = skin;
	}

	public Animal getAnimal() {
		return animal;
	}

	public void setAnimal(Animal animal) {
		this.animal = animal;
	}
	
	public Inventaire getInventaire() {
		return inventaire;
	}
	 
	

	// Methode pour afficher les informations du Hero
	
	public void afficherHeros() {
		System.out.println("ID du heros : " + herosID);
        System.out.println("Nom du heros : " + name);
        System.out.println("Niveau du heros : " + level);
        System.out.println("Argent du heros : " + piece);
        System.out.println("ID de l utisateur : " + userID);
	}
	
	 
	public void rename(String name) {
		this.name = name ;
	}
	 
	public void gainExp(int a) {
		 if (level > 10) {
			 System.out.println("Vous avez atteint le niveau maximal !");
		 }
		 else if ( this.exp +a >= 100 ) {
			 level++;
			 System.out.println("Vous avez atteint le niveau "+this.level+"!");
			 this.exp = (this.exp + a )% 100;
		 }
		 else {
			 this.exp +=  a;		 
		 }
	 }
	
	
	// lancer une attaque
	public abstract void attaquerMonstre(Monster m);
	
	// methodes pour les interfaces associées
	
	@Override
	public void AcheterAnimal(AnimalMagic animalm) {
		if(animalm.getPrice()> this.piece) {
			System.out.println("Echec: Vous avez pas assez de piece.");
		}
		else {
			this.piece = this.getPiece() - animalm.getPrice();
	        Animal animalAcheter = new Animal(animalm.getName(),this);

	        // Ajouter à l'inventaire
	        Inventaire inventaire = this.getInventaire();
	        inventaire.ajouterAnimal(animalAcheter);
		}
	};
	
	
	@Override
	public void CaptureMonstre(Monster monstre) {
        Animal animalCapturé = new Animal(monstre.getName(),this);

        // Définir que l'animal est capturé
        animalCapturé.sauvageCapture = true;
        
        // Ajouter à l'inventaire
        Inventaire inventaire = this.getInventaire();
        inventaire.ajouterAnimal(animalCapturé);
	};
	

	@Override
	public void equipeFee(Fee fee) {
		this.fee = fee;
		this.skin = null;
	};
	
	@Override
	// pour utiliser un skin il faut utiliser une fee de meme element
	public void equipeSkin(Skin skin) {
		if(this.fee.getEle()==skin.getElement()) {
			this.skin = skin;
			System.out.println("Vous avez mis le skin: ");
			skin.afficherSkin();
		}
		else {
			System.out.println("Impossible d'utiliser le skin. ");
		}
	};
	
	@Override
	public void equipeAnimal(Animal animal) {
		this.animal = animal ;
	}
	
	// autres methodes 
	public void acheterFee(Fee fee) {
		if(fee.getPrice()>this.getPiece()) {
			System.out.println("Echec: Vous avez pas assez de piece");
		}
		else {
			this.piece = this.getPiece() - fee.getPrice();
			
	        // Ajouter à l'inventaire
	        Inventaire inventaire = this.getInventaire();
	        inventaire.ajouterFee(fee);					
		}
	}
	
	public void ObtientSkin(Skin skin) {
        // Ajouter à l'inventaire
        Inventaire inventaire = this.getInventaire();
        inventaire.ajouterSkin(skin);
	}
	
	// Methode principal
	public static void main(String[] args) {
		// Création d'une instance de la classe Heros
		Sorcier monHeros = new Sorcier("Superman", 1);
		 
		// Affichage des informations du héros
		monHeros.afficherHeros();
	       
		// test renommage
		monHeros.rename("Batman");
	    monHeros.afficherHeros();
	    
	    // test attaque
	    Monster monster1 =  new Monster( "poule sauvage", 1, 50,100);
	    monHeros.attaquerMonstre(monster1);
	    monHeros.attaquerMonstre(monster1);
	}


	
}
