package univers;

public interface Equipement {
	
	// pour equiper le heros qui ne peut avoir qu'un seul animal, une seule fée et un skin avec lui
	public void equipeFee(Fee fee);
	public void equipeAnimal(Animal animal);
	public void equipeSkin(Skin skin);

}
