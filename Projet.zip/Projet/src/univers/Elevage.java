package univers;

public interface Elevage {
	public void AcheterAnimal(AnimalMagic animalm);
	public void CaptureMonstre(Monster monstre);

}
