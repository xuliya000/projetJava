package representation;

public abstract class InnerNode extends Node {
	protected Node[] nextNodes= new Node[4];

	//Constructeur
	public InnerNode (String description, Node[] nextNodes) {
		super(description);
		System.arraycopy(nextNodes, 0, this.nextNodes, 0, 4);
	}
	
	public abstract Node chooseNext();
	
	// Getters et setters
	public Node[] getNextNodes() {
		return nextNodes ;
	}
	
	public void setNextNodes(Node[] nextNodes) {
		this.nextNodes = nextNodes ;
	}
	
}
