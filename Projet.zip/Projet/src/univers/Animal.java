package univers;

public class Animal {
	private Heros heros;
	private String name ;
	protected boolean sauvageCapture = false ;
	
	// constructeur
	public Animal(String name, Heros heros) {
		this.setHeros(heros);
		this.name = name;
	}
	
	// getters et setters

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public boolean isSauvageCapture() {
		return sauvageCapture;
	}
	
	public Heros getHeros() {
		return heros;
	}

	public void setHeros(Heros heros) {
		this.heros = heros;
	}
	
	// methode pour afficher
	public void afficherAnimal() {
		System.out.println("Nom : "+this.getName()+", Sauvage capturé : "+ this.isSauvageCapture());
	}
	
	
    // Méthode pour capturer un monstre (animal sauvage) et renvoyer un animal
    public static Animal capture(Monster monster , Heros heros) {
        Animal animalCapturé = new Animal(monster.getName(),heros);

        // Définir que l'animal est capturé
        animalCapturé.sauvageCapture = true;
        
        // Ajouter à l'inventaire
        Inventaire inventaire = heros.getInventaire();
        inventaire.ajouterAnimal(animalCapturé);

        return animalCapturé;
    }




	
}
