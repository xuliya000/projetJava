package univers;

public class Skin {
    private static int nbSkin = 0;
    private final int skinId;
    private Metier metier;
    private Element element;
    private int niv;

    // constructeur
    public Skin(Metier metier, Element element, int niv) {
        this.skinId = ++nbSkin;
        this.metier = metier;
        this.element = element;
        this.niv = niv;
    }

    // getters et setters

    public Element getElement() {
        return element;
    }

    public void setElement(Element element) {
        this.element = element;
    }

    public int getNiv() {
        return niv;
    }

    public void setNiv(int niv) {
        this.niv = niv;
    }

    public static int getNbSkin() {
        return nbSkin;
    }

    public static void setNbSkin(int nbSkin) {
        Skin.nbSkin = nbSkin;
    }

    public Metier getMetier() {
        return metier;
    }

    public int getSkinId() {
        return skinId;
    }
    
    // methode pour afficher
    public void afficherSkin() {
    	System.out.println("Skin pour "+this.getMetier()+", d'élément "+ this.getElement()+ " pour le porter il faut avoir le niveau "+ this.getNiv()+".");
    }
    
  
    
    
}
















